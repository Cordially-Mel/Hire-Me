import React from 'react';
import './App.css';

function App() {
  return (
    <main>
      React⚛️ + Vite⚡ + Replit🌀
      <p class="bruh">scroll down</p>
    </main>
  );
}

export default App;